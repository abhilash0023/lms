import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth, UserRole } from '../../contexts/AuthContext';

interface ProtectedRouteProps {
  children: React.ReactNode;
  allowedRoles?: UserRole[];
}

export default function ProtectedRoute({ 
  children, 
  allowedRoles = ['student', 'teacher', 'admin'] 
}: ProtectedRouteProps) {
  const { user, isAuthenticated, isLoading } = useAuth();
  const location = useLocation();

  // Show loading state while authentication status is being determined
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  // Redirect to login if not authenticated
  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // Redirect to unauthorized page if user doesn't have required role
  if (user && !allowedRoles.includes(user.role)) {
    // Redirect to role-specific dashboard based on the user's role
    if (user.role === 'student') {
      return <Navigate to="/student/dashboard" replace />;
    } 
    if (user.role === 'teacher') {
      return <Navigate to="/teacher/dashboard" replace />;
    }
    if (user.role === 'admin') {
      return <Navigate to="/admin/dashboard" replace />;
    }
    
    // Fallback to home page
    return <Navigate to="/" replace />;
  }

  // If authenticated and authorized, render the children
  return <>{children}</>;
}