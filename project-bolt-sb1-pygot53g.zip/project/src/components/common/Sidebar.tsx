import React from 'react';
import { NavLink } from 'react-router-dom';
import { X, Home, BookOpen, Users, FileText, Award, Settings, ClipboardCheck, BarChart } from 'lucide-react';
import { UserRole } from '../../contexts/AuthContext';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  userRole: UserRole;
}

export default function Sidebar({ isOpen, onClose, userRole }: SidebarProps) {
  // Define navigation links based on user role
  const getNavLinks = () => {
    switch (userRole) {
      case 'student':
        return [
          { name: 'Dashboard', path: '/student/dashboard', icon: <Home className="h-5 w-5" /> },
          { name: 'My Courses', path: '/student/courses', icon: <BookOpen className="h-5 w-5" /> },
          { name: 'Assessments', path: '/student/assessments', icon: <FileText className="h-5 w-5" /> },
          { name: 'Certificates', path: '/student/certificates', icon: <Award className="h-5 w-5" /> },
        ];
      case 'teacher':
        return [
          { name: 'Dashboard', path: '/teacher/dashboard', icon: <Home className="h-5 w-5" /> },
          { name: 'My Courses', path: '/teacher/courses', icon: <BookOpen className="h-5 w-5" /> },
          { name: 'Attendance', path: '/teacher/attendance', icon: <ClipboardCheck className="h-5 w-5" /> },
          { name: 'Assessments', path: '/teacher/assessments', icon: <FileText className="h-5 w-5" /> },
        ];
      case 'admin':
        return [
          { name: 'Dashboard', path: '/admin/dashboard', icon: <Home className="h-5 w-5" /> },
          { name: 'Users', path: '/admin/users', icon: <Users className="h-5 w-5" /> },
          { name: 'Courses', path: '/admin/courses', icon: <BookOpen className="h-5 w-5" /> },
          { name: 'Reports', path: '/admin/reports', icon: <BarChart className="h-5 w-5" /> },
          { name: 'Settings', path: '/admin/settings', icon: <Settings className="h-5 w-5" /> },
        ];
      default:
        return [];
    }
  };

  return (
    <>
      {/* Mobile sidebar backdrop */}
      {isOpen && (
        <div 
          className="fixed inset-0 z-20 bg-gray-900/50 lg:hidden"
          onClick={onClose}
        ></div>
      )}

      {/* Sidebar */}
      <aside
        className={`fixed top-0 left-0 z-30 h-screen w-64 bg-white border-r border-gray-200 transform transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:h-screen ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Sidebar header */}
        <div className="h-16 flex items-center justify-between px-4 border-b border-gray-200">
          <div className="flex items-center gap-2">
            <BookOpen className="h-7 w-7 text-primary-600" />
            <span className="text-lg font-bold">Smart Learn</span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-gray-600 rounded-md hover:bg-gray-100 lg:hidden"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Sidebar content */}
        <div className="px-3 py-4">
          <nav className="space-y-1">
            {getNavLinks().map((link) => (
              <NavLink
                key={link.path}
                to={link.path}
                onClick={onClose}
                className={({ isActive }) =>
                  `flex items-center px-3 py-2.5 text-sm font-medium rounded-md transition-colors ${
                    isActive
                      ? 'bg-primary-50 text-primary-700'
                      : 'text-gray-700 hover:bg-gray-100'
                  }`
                }
              >
                <span className="mr-3 text-gray-500">{link.icon}</span>
                {link.name}
              </NavLink>
            ))}
          </nav>

          {/* Role badge */}
          <div className="mt-6 px-3">
            <div className={`
              inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium 
              ${userRole === 'student' ? 'bg-primary-100 text-primary-800' : 
                userRole === 'teacher' ? 'bg-secondary-100 text-secondary-800' : 
                'bg-accent-100 text-accent-800'}
            `}>
              {userRole.charAt(0).toUpperCase() + userRole.slice(1)}
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}