import React, { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Menu, X, Search, BookOpen } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

export default function PublicHeader() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const { isAuthenticated, user } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');

  // Handle scroll event to change header style
  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY;
      setIsScrolled(scrollPosition > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Handle search submission
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/courses?search=${encodeURIComponent(searchQuery)}`);
      setSearchQuery('');
      setIsMenuOpen(false);
    }
  };

  // Get appropriate dashboard link based on user role
  const getDashboardLink = () => {
    if (!user) return '/login';
    switch (user.role) {
      case 'student': return '/student/dashboard';
      case 'teacher': return '/teacher/dashboard';
      case 'admin': return '/admin/dashboard';
      default: return '/login';
    }
  };

  return (
    <header 
      className={`fixed w-full z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'
      }`}
    >
      <div className="container mx-auto px-4 flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2">
          <BookOpen className="h-8 w-8 text-primary-600" />
          <span className="text-xl font-bold text-gray-900">Smart Learn</span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          <Link 
            to="/" 
            className={`text-sm font-medium transition-colors ${
              location.pathname === '/' 
                ? 'text-primary-600' 
                : 'text-gray-700 hover:text-primary-600'
            }`}
          >
            Home
          </Link>
          <Link 
            to="/courses" 
            className={`text-sm font-medium transition-colors ${
              location.pathname === '/courses' 
                ? 'text-primary-600' 
                : 'text-gray-700 hover:text-primary-600'
            }`}
          >
            Courses
          </Link>
          <Link 
            to="/about" 
            className={`text-sm font-medium transition-colors ${
              location.pathname === '/about' 
                ? 'text-primary-600' 
                : 'text-gray-700 hover:text-primary-600'
            }`}
          >
            About
          </Link>
          
          {/* Search form */}
          <form onSubmit={handleSearch} className="relative">
            <input
              type="text"
              placeholder="Search courses..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="py-2 pl-10 pr-4 w-64 rounded-md text-sm bg-gray-100 focus:bg-white border border-gray-300 focus:border-primary-500 focus:ring-1 focus:ring-primary-500 outline-none transition-all"
            />
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-500" />
          </form>
        </nav>

        {/* Auth buttons - Desktop */}
        <div className="hidden md:flex items-center space-x-4">
          {isAuthenticated ? (
            <Link 
              to={getDashboardLink()} 
              className="btn btn-primary btn-sm"
            >
              Dashboard
            </Link>
          ) : (
            <>
              <Link 
                to="/login" 
                className="text-sm font-medium text-gray-700 hover:text-primary-600 transition-colors"
              >
                Log in
              </Link>
              <Link 
                to="/register" 
                className="btn btn-primary btn-sm"
              >
                Sign up
              </Link>
            </>
          )}
        </div>

        {/* Mobile menu button */}
        <button
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          className="p-2 text-gray-700 rounded-md md:hidden"
          aria-label="Toggle menu"
        >
          {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div className="md:hidden bg-white shadow-lg animate-fade-in">
          <div className="container mx-auto px-4 py-4 flex flex-col">
            {/* Mobile search */}
            <form onSubmit={handleSearch} className="relative mb-4">
              <input
                type="text"
                placeholder="Search courses..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="py-2 pl-10 pr-4 w-full rounded-md text-sm bg-gray-100 focus:bg-white border border-gray-300 focus:border-primary-500 focus:ring-1 focus:ring-primary-500 outline-none transition-all"
              />
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-500" />
            </form>
            
            {/* Navigation links */}
            <nav className="flex flex-col space-y-4">
              <Link 
                to="/" 
                onClick={() => setIsMenuOpen(false)}
                className={`text-base font-medium transition-colors ${
                  location.pathname === '/' 
                    ? 'text-primary-600' 
                    : 'text-gray-700'
                }`}
              >
                Home
              </Link>
              <Link 
                to="/courses" 
                onClick={() => setIsMenuOpen(false)}
                className={`text-base font-medium transition-colors ${
                  location.pathname === '/courses' 
                    ? 'text-primary-600' 
                    : 'text-gray-700'
                }`}
              >
                Courses
              </Link>
              <Link 
                to="/about" 
                onClick={() => setIsMenuOpen(false)}
                className={`text-base font-medium transition-colors ${
                  location.pathname === '/about' 
                    ? 'text-primary-600' 
                    : 'text-gray-700'
                }`}
              >
                About
              </Link>
              
              {/* Mobile auth buttons */}
              <div className="pt-4 border-t border-gray-200">
                {isAuthenticated ? (
                  <Link 
                    to={getDashboardLink()} 
                    onClick={() => setIsMenuOpen(false)}
                    className="btn btn-primary btn-md w-full"
                  >
                    Dashboard
                  </Link>
                ) : (
                  <div className="space-y-3">
                    <Link 
                      to="/login" 
                      onClick={() => setIsMenuOpen(false)}
                      className="btn btn-outline btn-md w-full"
                    >
                      Log in
                    </Link>
                    <Link 
                      to="/register" 
                      onClick={() => setIsMenuOpen(false)}
                      className="btn btn-primary btn-md w-full"
                    >
                      Sign up
                    </Link>
                  </div>
                )}
              </div>
            </nav>
          </div>
        </div>
      )}
    </header>
  );
}