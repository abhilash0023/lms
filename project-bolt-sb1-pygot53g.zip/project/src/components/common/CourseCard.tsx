import React from 'react';
import { Link } from 'react-router-dom';
import { Calendar, Clock, Star, Users } from 'lucide-react';
import { formatDate } from '../../utils/helpers';

export interface CourseCardProps {
  id: string;
  title: string;
  description: string;
  instructor: string;
  thumbnail: string;
  category: string;
  rating: number;
  studentsCount: number;
  duration: string;
  startDate?: string;
  progress?: number;
  isEnrolled?: boolean;
  linkTo?: string;
}

export default function CourseCard({
  id,
  title,
  description,
  instructor,
  thumbnail,
  category,
  rating,
  studentsCount,
  duration,
  startDate,
  progress,
  isEnrolled = false,
  linkTo,
}: CourseCardProps) {
  const defaultLink = `/courses/${id}`;
  
  return (
    <div className="card group h-full transition-all duration-300 hover:shadow-md">
      <Link to={linkTo || defaultLink} className="block">
        <div className="relative h-40 overflow-hidden">
          <img
            src={thumbnail}
            alt={title}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
          <div className="absolute top-3 left-3">
            <span className="badge badge-primary">{category}</span>
          </div>
          {isEnrolled && progress !== undefined && (
            <div className="absolute bottom-0 left-0 right-0 h-1.5 bg-gray-200">
              <div 
                className="h-full bg-primary-500" 
                style={{ width: `${progress}%` }}
              ></div>
            </div>
          )}
        </div>
      </Link>

      <div className="p-4">
        {/* Title and instructor */}
        <Link to={linkTo || defaultLink} className="block">
          <h3 className="text-lg font-semibold line-clamp-2 group-hover:text-primary-600 transition-colors mb-1">
            {title}
          </h3>
        </Link>
        <p className="text-sm text-gray-600 mb-2">by {instructor}</p>

        {/* Description */}
        <p className="text-sm text-gray-700 line-clamp-2 mb-4">
          {description}
        </p>

        {/* Course stats */}
        <div className="flex flex-wrap gap-y-2 text-xs text-gray-600 mb-4">
          <div className="flex items-center mr-4">
            <Clock className="h-3.5 w-3.5 mr-1" />
            <span>{duration}</span>
          </div>
          <div className="flex items-center mr-4">
            <Users className="h-3.5 w-3.5 mr-1" />
            <span>{studentsCount} students</span>
          </div>
          <div className="flex items-center">
            <Star className="h-3.5 w-3.5 text-yellow-500 mr-1" />
            <span>{rating.toFixed(1)}</span>
          </div>
        </div>

        {/* Start date if available */}
        {startDate && (
          <div className="flex items-center text-xs text-gray-600 mb-2">
            <Calendar className="h-3.5 w-3.5 mr-1" />
            <span>Starts on {formatDate(startDate, { month: 'short', day: 'numeric', year: 'numeric' })}</span>
          </div>
        )}

        {/* Action button or progress */}
        {isEnrolled ? (
          <div className="flex justify-between items-center mt-auto">
            <span className="text-xs font-medium text-gray-700">
              {progress === 100 ? 'Completed' : `${progress}% complete`}
            </span>
            <Link 
              to={linkTo || defaultLink} 
              className="btn btn-sm btn-primary"
            >
              {progress === 100 ? 'View Certificate' : 'Continue Learning'}
            </Link>
          </div>
        ) : (
          <Link 
            to={linkTo || defaultLink} 
            className="btn btn-sm btn-outline w-full mt-auto"
          >
            View Details
          </Link>
        )}
      </div>
    </div>
  );
}