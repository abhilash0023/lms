import React from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Clock, Award, FileText, ArrowRight, Calendar, Bell } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import CourseCard from '../../components/common/CourseCard';

// Mock data for in progress courses
const inProgressCourses = [
  {
    id: '1',
    title: 'Introduction to Computer Science',
    description: 'Learn the fundamentals of computer science and programming with Python.',
    instructor: 'Dr. Jane Smith',
    thumbnail: 'https://images.pexels.com/photos/2004161/pexels-photo-2004161.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
    category: 'Computer Science',
    rating: 4.8,
    studentsCount: 1250,
    duration: '8 weeks',
    progress: 75,
    isEnrolled: true,
    linkTo: '/student/courses/1',
  },
  {
    id: '2',
    title: 'Web Development Bootcamp',
    description: 'Master HTML, CSS, JavaScript, React, Node.js and build full-stack applications.',
    instructor: 'John Doe',
    thumbnail: 'https://images.pexels.com/photos/270348/pexels-photo-270348.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
    category: 'Web Development',
    rating: 4.9,
    studentsCount: 2378,
    duration: '12 weeks',
    progress: 32,
    isEnrolled: true,
    linkTo: '/student/courses/2',
  },
];

// Mock data for upcoming deadlines
const upcomingDeadlines = [
  {
    id: '1',
    title: 'Python Quiz 2',
    course: 'Introduction to Computer Science',
    dueDate: '2025-04-10T23:59:59',
    type: 'quiz',
  },
  {
    id: '2',
    title: 'Final Project Submission',
    course: 'Web Development Bootcamp',
    dueDate: '2025-04-15T23:59:59',
    type: 'assignment',
  },
  {
    id: '3',
    title: 'Code Review Exercise',
    course: 'Web Development Bootcamp',
    dueDate: '2025-04-08T23:59:59',
    type: 'assignment',
  },
];

// Mock data for recent announcements
const recentAnnouncements = [
  {
    id: '1',
    title: 'New Module Added: Advanced Python Concepts',
    course: 'Introduction to Computer Science',
    date: '2025-04-02T10:15:00',
  },
  {
    id: '2',
    title: 'Live Coding Session Next Week',
    course: 'Web Development Bootcamp',
    date: '2025-04-01T14:30:00',
  },
];

export default function StudentDashboard() {
  const { user } = useAuth();
  
  return (
    <div className="animate-fade-in">
      {/* Welcome Section */}
      <section className="mb-8">
        <h1 className="text-2xl font-bold mb-1">Hello, {user?.firstName} 👋</h1>
        <p className="text-gray-600">Welcome to your learning dashboard</p>
      </section>

      {/* Stats Overview */}
      <section className="mb-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-white rounded-lg shadow-sm p-6 flex items-center border border-gray-100">
            <div className="rounded-full bg-primary-100 p-3 mr-4">
              <BookOpen className="h-6 w-6 text-primary-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Enrolled Courses</p>
              <p className="text-2xl font-semibold">2</p>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-sm p-6 flex items-center border border-gray-100">
            <div className="rounded-full bg-secondary-100 p-3 mr-4">
              <Clock className="h-6 w-6 text-secondary-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Hours Learned</p>
              <p className="text-2xl font-semibold">24.5</p>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-sm p-6 flex items-center border border-gray-100">
            <div className="rounded-full bg-accent-100 p-3 mr-4">
              <Award className="h-6 w-6 text-accent-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Certificates</p>
              <p className="text-2xl font-semibold">1</p>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-sm p-6 flex items-center border border-gray-100">
            <div className="rounded-full bg-success-100 p-3 mr-4">
              <FileText className="h-6 w-6 text-success-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Completed Assessments</p>
              <p className="text-2xl font-semibold">12</p>
            </div>
          </div>
        </div>
      </section>

      {/* Continue Learning Section */}
      <section className="mb-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">Continue Learning</h2>
          <Link to="/student/courses" className="text-primary-600 hover:text-primary-700 text-sm font-medium flex items-center">
            View All <ArrowRight className="ml-1 h-4 w-4" />
          </Link>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {inProgressCourses.map((course) => (
            <CourseCard key={course.id} {...course} />
          ))}
        </div>
      </section>

      {/* Bottom Grid: Upcoming Deadlines and Announcements */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Upcoming Deadlines Section */}
        <section>
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold">Upcoming Deadlines</h2>
            <Link to="/student/assessments" className="text-primary-600 hover:text-primary-700 text-sm font-medium flex items-center">
              View All <ArrowRight className="ml-1 h-4 w-4" />
            </Link>
          </div>
          <div className="bg-white rounded-lg shadow-sm border border-gray-100 overflow-hidden">
            <ul className="divide-y divide-gray-200">
              {upcomingDeadlines.map((deadline) => (
                <li key={deadline.id} className="p-4 hover:bg-gray-50">
                  <Link to="/student/assessments" className="block">
                    <div className="flex justify-between">
                      <div>
                        <p className="font-medium text-gray-900">{deadline.title}</p>
                        <p className="text-sm text-gray-600">{deadline.course}</p>
                      </div>
                      <div className="flex items-center">
                        <span className={`
                          inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium mr-2
                          ${deadline.type === 'quiz' ? 'bg-secondary-100 text-secondary-800' : 'bg-accent-100 text-accent-800'}
                        `}>
                          {deadline.type === 'quiz' ? 'Quiz' : 'Assignment'}
                        </span>
                      </div>
                    </div>
                    <div className="mt-2 flex items-center text-sm text-gray-500">
                      <Calendar className="h-4 w-4 mr-1" />
                      <span>{new Date(deadline.dueDate).toLocaleDateString('en-US', { 
                        month: 'short', 
                        day: 'numeric', 
                        year: 'numeric',
                      })}</span>
                    </div>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </section>

        {/* Recent Announcements Section */}
        <section>
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold">Recent Announcements</h2>
          </div>
          <div className="bg-white rounded-lg shadow-sm border border-gray-100 overflow-hidden">
            <ul className="divide-y divide-gray-200">
              {recentAnnouncements.map((announcement) => (
                <li key={announcement.id} className="p-4 hover:bg-gray-50">
                  <div>
                    <div className="flex items-start">
                      <Bell className="h-5 w-5 text-primary-600 mt-0.5 mr-2" />
                      <div>
                        <p className="font-medium text-gray-900">{announcement.title}</p>
                        <p className="text-sm text-gray-600">{announcement.course}</p>
                        <p className="text-xs text-gray-500 mt-1">
                          {new Date(announcement.date).toLocaleDateString('en-US', { 
                            month: 'short', 
                            day: 'numeric', 
                            year: 'numeric',
                          })}
                        </p>
                      </div>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </section>
      </div>
    </div>
  );
}