import React from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Users, FileText, Clock, ArrowRight, Calendar, Mail } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

// Mock data for stats
const statsData = [
  { name: 'Courses', value: 3, icon: <BookOpen className="h-6 w-6 text-primary-600" />, bgColor: 'bg-primary-100' },
  { name: 'Students', value: 78, icon: <Users className="h-6 w-6 text-secondary-600" />, bgColor: 'bg-secondary-100' },
  { name: 'Assessments', value: 15, icon: <FileText className="h-6 w-6 text-accent-600" />, bgColor: 'bg-accent-100' },
  { name: 'Hours Taught', value: 42, icon: <Clock className="h-6 w-6 text-success-600" />, bgColor: 'bg-success-100' },
];

// Mock data for student activity chart
const studentActivityData = [
  { name: 'Mon', active: 45, completed: 22 },
  { name: 'Tue', active: 52, completed: 28 },
  { name: 'Wed', active: 49, completed: 30 },
  { name: 'Thu', active: 60, completed: 35 },
  { name: 'Fri', active: 55, completed: 40 },
  { name: 'Sat', active: 30, completed: 25 },
  { name: 'Sun', active: 32, completed: 20 },
];

// Mock data for recent submissions
const recentSubmissions = [
  {
    id: '1',
    studentName: 'John Smith',
    assessmentTitle: 'Python Quiz 2',
    course: 'Introduction to Computer Science',
    submittedDate: '2025-04-02T10:15:00',
  },
  {
    id: '2',
    studentName: 'Emily Johnson',
    assessmentTitle: 'Final Project',
    course: 'Web Development Bootcamp',
    submittedDate: '2025-04-01T14:30:00',
  },
  {
    id: '3',
    studentName: 'Michael Brown',
    assessmentTitle: 'Code Review Exercise',
    course: 'Web Development Bootcamp',
    submittedDate: '2025-03-31T09:45:00',
  },
];

// Mock data for upcoming schedule
const upcomingSchedule = [
  {
    id: '1',
    title: 'Introduction to JavaScript',
    course: 'Web Development Bootcamp',
    date: '2025-04-05T10:00:00',
    duration: '1.5 hours',
  },
  {
    id: '2',
    title: 'Python Data Structures',
    course: 'Introduction to Computer Science',
    date: '2025-04-06T14:00:00',
    duration: '2 hours',
  },
  {
    id: '3',
    title: 'Office Hours',
    course: 'All courses',
    date: '2025-04-07T11:00:00',
    duration: '1 hour',
  },
];

export default function TeacherDashboard() {
  const { user } = useAuth();
  
  return (
    <div className="animate-fade-in">
      {/* Welcome Section */}
      <section className="mb-8">
        <h1 className="text-2xl font-bold mb-1">Welcome back, {user?.firstName} 👋</h1>
        <p className="text-gray-600">Track your teaching activity and manage your courses</p>
      </section>

      {/* Stats Overview */}
      <section className="mb-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {statsData.map((stat, index) => (
            <div key={index} className="bg-white rounded-lg shadow-sm p-6 flex items-center border border-gray-100">
              <div className={`rounded-full ${stat.bgColor} p-3 mr-4`}>
                {stat.icon}
              </div>
              <div>
                <p className="text-sm text-gray-600">{stat.name}</p>
                <p className="text-2xl font-semibold">{stat.value}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Activity Chart */}
      <section className="mb-8">
        <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-6">
          <h2 className="text-xl font-semibold mb-4">Student Activity</h2>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={studentActivityData}
                margin={{ top: 5, right: 30, left: 0, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="active" name="Active Students" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                <Bar dataKey="completed" name="Completed Lessons" fill="#14b8a6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </section>

      {/* Bottom Grid: Recent Submissions and Upcoming Schedule */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Recent Submissions Section */}
        <section>
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold">Recent Submissions</h2>
            <Link to="/teacher/assessments" className="text-primary-600 hover:text-primary-700 text-sm font-medium flex items-center">
              Grade Submissions <ArrowRight className="ml-1 h-4 w-4" />
            </Link>
          </div>
          <div className="bg-white rounded-lg shadow-sm border border-gray-100 overflow-hidden">
            <ul className="divide-y divide-gray-200">
              {recentSubmissions.map((submission) => (
                <li key={submission.id} className="p-4 hover:bg-gray-50">
                  <Link to="/teacher/assessments" className="block">
                    <div className="flex justify-between">
                      <div>
                        <p className="font-medium text-gray-900">{submission.studentName}</p>
                        <p className="text-sm text-gray-600">{submission.assessmentTitle}</p>
                        <p className="text-xs text-gray-500">{submission.course}</p>
                      </div>
                      <div className="flex items-center">
                        <span className="inline-flex items-center rounded-full bg-secondary-100 text-secondary-800 px-2.5 py-0.5 text-xs font-medium">
                          Needs Grading
                        </span>
                      </div>
                    </div>
                    <div className="mt-2 flex items-center text-sm text-gray-500">
                      <Mail className="h-4 w-4 mr-1" />
                      <span>Submitted {new Date(submission.submittedDate).toLocaleDateString('en-US', { 
                        month: 'short', 
                        day: 'numeric', 
                        year: 'numeric',
                      })}</span>
                    </div>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </section>

        {/* Upcoming Schedule Section */}
        <section>
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold">Upcoming Schedule</h2>
            <Link to="/teacher/courses" className="text-primary-600 hover:text-primary-700 text-sm font-medium flex items-center">
              View Calendar <ArrowRight className="ml-1 h-4 w-4" />
            </Link>
          </div>
          <div className="bg-white rounded-lg shadow-sm border border-gray-100 overflow-hidden">
            <ul className="divide-y divide-gray-200">
              {upcomingSchedule.map((item) => (
                <li key={item.id} className="p-4 hover:bg-gray-50">
                  <div>
                    <div className="flex items-start">
                      <Calendar className="h-5 w-5 text-primary-600 mt-0.5 mr-3" />
                      <div>
                        <p className="font-medium text-gray-900">{item.title}</p>
                        <p className="text-sm text-gray-600">{item.course}</p>
                        <div className="flex flex-wrap mt-1 gap-2">
                          <p className="text-xs text-gray-500">
                            {new Date(item.date).toLocaleDateString('en-US', { 
                              month: 'short', 
                              day: 'numeric', 
                              year: 'numeric',
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </p>
                          <p className="text-xs text-gray-500">
                            {item.duration}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </section>
      </div>
    </div>
  );
}