import React from 'react';
import { useParams } from 'react-router-dom';
import { Clock, Users, Star, Calendar, BookOpen, Award } from 'lucide-react';

export default function CourseDetailPage() {
  const { id } = useParams();

  // Mock course data - in a real app, this would be fetched from an API
  const course = {
    id,
    title: 'Introduction to Computer Science',
    description: 'Learn the fundamentals of computer science and programming with Python. This comprehensive course covers basic programming concepts, data structures, algorithms, and problem-solving techniques.',
    instructor: {
      name: 'Dr. Jane Smith',
      title: 'Professor of Computer Science',
      image: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      bio: 'Dr. Smith has over 15 years of experience teaching computer science at leading universities.',
    },
    thumbnail: 'https://images.pexels.com/photos/2004161/pexels-photo-2004161.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
    category: 'Computer Science',
    rating: 4.8,
    studentsCount: 1250,
    duration: '8 weeks',
    startDate: '2025-05-01',
    price: 49.99,
    modules: [
      {
        title: 'Introduction to Programming',
        lessons: [
          'Understanding Programming Basics',
          'Variables and Data Types',
          'Control Structures',
        ],
      },
      {
        title: 'Data Structures',
        lessons: [
          'Arrays and Lists',
          'Dictionaries and Sets',
          'Advanced Data Structures',
        ],
      },
      {
        title: 'Algorithms',
        lessons: [
          'Basic Algorithms',
          'Searching and Sorting',
          'Algorithm Analysis',
        ],
      },
    ],
  };

  return (
    <div className="min-h-screen pt-20 pb-12">
      {/* Course Header */}
      <div className="bg-gradient-to-r from-primary-900 to-primary-700 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="flex flex-col lg:flex-row gap-8">
            {/* Course Info */}
            <div className="lg:w-2/3">
              <h1 className="text-3xl md:text-4xl font-bold mb-4">{course.title}</h1>
              <p className="text-lg text-primary-100 mb-6">{course.description}</p>
              
              <div className="flex flex-wrap gap-4 text-sm mb-6">
                <div className="flex items-center">
                  <Clock className="h-4 w-4 mr-1" />
                  <span>{course.duration}</span>
                </div>
                <div className="flex items-center">
                  <Users className="h-4 w-4 mr-1" />
                  <span>{course.studentsCount} students</span>
                </div>
                <div className="flex items-center">
                  <Star className="h-4 w-4 text-yellow-400 mr-1" />
                  <span>{course.rating} rating</span>
                </div>
                <div className="flex items-center">
                  <Calendar className="h-4 w-4 mr-1" />
                  <span>Starts {new Date(course.startDate).toLocaleDateString()}</span>
                </div>
              </div>

              <div className="flex items-center mb-6">
                <img 
                  src={course.instructor.image} 
                  alt={course.instructor.name}
                  className="h-12 w-12 rounded-full mr-4"
                />
                <div>
                  <p className="font-medium">{course.instructor.name}</p>
                  <p className="text-sm text-primary-100">{course.instructor.title}</p>
                </div>
              </div>

              <button className="btn btn-accent btn-lg">
                Enroll Now - ${course.price}
              </button>
            </div>

            {/* Course Thumbnail */}
            <div className="lg:w-1/3">
              <div className="relative aspect-video rounded-lg overflow-hidden shadow-xl">
                <img 
                  src={course.thumbnail} 
                  alt={course.title}
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Course Content */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* What You'll Learn */}
            <section className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8">
              <h2 className="text-2xl font-semibold mb-4">What You'll Learn</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-start">
                  <BookOpen className="h-5 w-5 text-primary-600 mt-1 mr-2" />
                  <span>Master Python programming fundamentals</span>
                </div>
                <div className="flex items-start">
                  <BookOpen className="h-5 w-5 text-primary-600 mt-1 mr-2" />
                  <span>Understand key data structures and algorithms</span>
                </div>
                <div className="flex items-start">
                  <BookOpen className="h-5 w-5 text-primary-600 mt-1 mr-2" />
                  <span>Build practical programming projects</span>
                </div>
                <div className="flex items-start">
                  <BookOpen className="h-5 w-5 text-primary-600 mt-1 mr-2" />
                  <span>Develop problem-solving skills</span>
                </div>
              </div>
            </section>

            {/* Course Content */}
            <section className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h2 className="text-2xl font-semibold mb-4">Course Content</h2>
              <div className="space-y-4">
                {course.modules.map((module, index) => (
                  <div key={index} className="border border-gray-200 rounded-lg">
                    <div className="p-4 bg-gray-50 font-medium">
                      {module.title}
                    </div>
                    <ul className="divide-y divide-gray-200">
                      {module.lessons.map((lesson, lessonIndex) => (
                        <li key={lessonIndex} className="p-4 flex items-center">
                          <BookOpen className="h-4 w-4 text-gray-400 mr-2" />
                          {lesson}
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </section>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            {/* Course Features */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8">
              <h3 className="text-lg font-semibold mb-4">Course Features</h3>
              <ul className="space-y-4">
                <li className="flex items-center">
                  <Award className="h-5 w-5 text-primary-600 mr-2" />
                  <span>Certificate of completion</span>
                </li>
                <li className="flex items-center">
                  <Clock className="h-5 w-5 text-primary-600 mr-2" />
                  <span>Self-paced learning</span>
                </li>
                <li className="flex items-center">
                  <Users className="h-5 w-5 text-primary-600 mr-2" />
                  <span>Expert instructor support</span>
                </li>
              </ul>
            </div>

            {/* Prerequisites */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold mb-4">Prerequisites</h3>
              <ul className="space-y-2 text-gray-600">
                <li>• Basic computer literacy</li>
                <li>• No prior programming experience required</li>
                <li>• Willingness to learn and practice</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}