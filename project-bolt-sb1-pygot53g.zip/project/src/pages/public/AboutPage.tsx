import React from 'react';
import { GraduationCap, Users, Award, BookOpen } from 'lucide-react';

const AboutPage = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="bg-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-gray-900 sm:text-5xl md:text-6xl">
              About Our Learning Platform
            </h1>
            <p className="mt-3 max-w-2xl mx-auto text-xl text-gray-500 sm:mt-4">
              Empowering students and educators through innovative online learning solutions
            </p>
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="bg-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
            <div className="text-center">
              <div className="flex justify-center">
                <GraduationCap className="h-12 w-12 text-indigo-600" />
              </div>
              <p className="mt-4 text-3xl font-semibold text-gray-900">10,000+</p>
              <p className="mt-2 text-lg text-gray-500">Students Enrolled</p>
            </div>
            <div className="text-center">
              <div className="flex justify-center">
                <Users className="h-12 w-12 text-indigo-600" />
              </div>
              <p className="mt-4 text-3xl font-semibold text-gray-900">500+</p>
              <p className="mt-2 text-lg text-gray-500">Expert Instructors</p>
            </div>
            <div className="text-center">
              <div className="flex justify-center">
                <BookOpen className="h-12 w-12 text-indigo-600" />
              </div>
              <p className="mt-4 text-3xl font-semibold text-gray-900">1,000+</p>
              <p className="mt-2 text-lg text-gray-500">Courses Available</p>
            </div>
            <div className="text-center">
              <div className="flex justify-center">
                <Award className="h-12 w-12 text-indigo-600" />
              </div>
              <p className="mt-4 text-3xl font-semibold text-gray-900">95%</p>
              <p className="mt-2 text-lg text-gray-500">Satisfaction Rate</p>
            </div>
          </div>
        </div>
      </div>

      {/* Mission Section */}
      <div className="bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-gray-900">Our Mission</h2>
            <p className="mt-4 text-lg text-gray-500 max-w-3xl mx-auto">
              We are dedicated to making quality education accessible to everyone. Our platform combines cutting-edge technology with expert instruction to create an engaging and effective learning experience.
            </p>
          </div>

          <div className="mt-16">
            <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
              <div className="bg-white rounded-lg shadow-lg p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Quality Education</h3>
                <p className="text-gray-600">
                  We partner with leading educators and institutions to deliver high-quality course content.
                </p>
              </div>
              <div className="bg-white rounded-lg shadow-lg p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Flexible Learning</h3>
                <p className="text-gray-600">
                  Learn at your own pace with our flexible course schedules and on-demand content.
                </p>
              </div>
              <div className="bg-white rounded-lg shadow-lg p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Interactive Experience</h3>
                <p className="text-gray-600">
                  Engage with instructors and peers through our interactive learning platform.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutPage;