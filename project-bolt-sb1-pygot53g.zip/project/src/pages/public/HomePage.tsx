import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, PlayCircle, BookOpen, Award, Users, CheckCircle } from 'lucide-react';
import CourseCard from '../../components/common/CourseCard';

// Mock featured courses data
const featuredCourses = [
  {
    id: '1',
    title: 'Introduction to Computer Science',
    description: 'Learn the fundamentals of computer science and programming with Python.',
    instructor: 'Dr. Jane Smith',
    thumbnail: 'https://images.pexels.com/photos/2004161/pexels-photo-2004161.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
    category: 'Computer Science',
    rating: 4.8,
    studentsCount: 1250,
    duration: '8 weeks',
  },
  {
    id: '2',
    title: 'Web Development Bootcamp',
    description: 'Master HTML, CSS, JavaScript, React, Node.js and build full-stack applications.',
    instructor: 'John Doe',
    thumbnail: 'https://images.pexels.com/photos/270348/pexels-photo-270348.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
    category: 'Web Development',
    rating: 4.9,
    studentsCount: 2378,
    duration: '12 weeks',
  },
  {
    id: '3',
    title: 'Data Science Fundamentals',
    description: 'Learn data analysis, visualization, machine learning, and statistical methods.',
    instructor: 'Dr. Michael Brown',
    thumbnail: 'https://images.pexels.com/photos/669615/pexels-photo-669615.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
    category: 'Data Science',
    rating: 4.7,
    studentsCount: 1842,
    duration: '10 weeks',
  },
];

export default function HomePage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-primary-900 to-primary-700 text-white pt-32 pb-20">
        <div className="container mx-auto px-4 flex flex-col lg:flex-row items-center gap-12">
          <div className="lg:w-1/2 animate-fade-in">
            <h1 className="text-4xl md:text-5xl font-bold mb-6 leading-tight">
              Transform Your Future with Smart Learning
            </h1>
            <p className="text-lg md:text-xl text-primary-100 mb-8 max-w-lg">
              Discover high-quality courses, expert instructors, and a personalized learning experience designed to help you achieve your goals.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to="/courses" className="btn btn-accent btn-lg">
                Explore Courses
              </Link>
              <Link to="/about" className="btn btn-lg bg-white/10 backdrop-blur-sm hover:bg-white/20 text-white">
                Learn More
              </Link>
            </div>
          </div>
          <div className="lg:w-1/2 animate-slide-up">
            <img 
              src="https://images.pexels.com/photos/4050315/pexels-photo-4050315.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" 
              alt="Students learning online" 
              className="rounded-lg shadow-2xl"
            />
          </div>
        </div>
        
        {/* Wave SVG */}
        <div className="absolute bottom-0 left-0 right-0 h-16 overflow-hidden">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 120" preserveAspectRatio="none" className="absolute bottom-0 w-full h-full">
            <path d="M0,0V46.29c47.79,22.2,103.59,32.17,158,28,70.36-5.37,136.33-33.31,206.8-37.5C438.64,32.43,512.34,53.67,583,72.05c69.27,18,138.3,24.88,209.4,13.08,36.15-6,69.85-17.84,104.45-29.34C989.49,25,1113-14.29,1200,52.47V0Z" opacity=".25" className="fill-white"></path>
            <path d="M0,0V15.81C13,36.92,27.64,56.86,47.69,72.05,99.41,111.27,165,111,224.58,91.58c31.15-10.15,60.09-26.07,89.67-39.8,40.92-19,84.73-46,130.83-49.67,36.26-2.85,70.9,9.42,98.6,31.56,31.77,25.39,62.32,62,103.63,73,40.44,10.79,81.35-6.69,119.13-24.28s75.16-39,116.92-43.05c59.73-5.85,113.28,22.88,168.9,38.84,30.2,8.66,59,6.17,87.09-7.5,22.43-10.89,48-26.93,60.65-49.24V0Z" opacity=".5" className="fill-white"></path>
            <path d="M0,0V5.63C149.93,59,314.09,71.32,475.83,42.57c43-7.64,84.23-20.12,127.61-26.46,59-8.63,112.48,12.24,165.56,35.4C827.93,77.22,886,95.24,951.2,90c86.53-7,172.46-45.71,248.8-84.81V0Z" className="fill-white"></path>
          </svg>
        </div>
      </section>

      {/* Statistics Section */}
      <section className="py-16 md:py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div className="animate-fade-in">
              <div className="text-4xl md:text-5xl font-bold text-primary-600 mb-2">100+</div>
              <p className="text-gray-600">Courses Available</p>
            </div>
            <div className="animate-fade-in" style={{ animationDelay: '0.2s' }}>
              <div className="text-4xl md:text-5xl font-bold text-primary-600 mb-2">50+</div>
              <p className="text-gray-600">Expert Instructors</p>
            </div>
            <div className="animate-fade-in" style={{ animationDelay: '0.4s' }}>
              <div className="text-4xl md:text-5xl font-bold text-primary-600 mb-2">10K+</div>
              <p className="text-gray-600">Active Students</p>
            </div>
            <div className="animate-fade-in" style={{ animationDelay: '0.6s' }}>
              <div className="text-4xl md:text-5xl font-bold text-primary-600 mb-2">95%</div>
              <p className="text-gray-600">Satisfaction Rate</p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Courses Section */}
      <section className="py-16 md:py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-12">
            <h2 className="text-3xl font-bold">Featured Courses</h2>
            <Link to="/courses" className="flex items-center text-primary-600 hover:text-primary-700 font-medium">
              View All Courses <ArrowRight className="ml-1 h-4 w-4" />
            </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredCourses.map((course) => (
              <div key={course.id} className="animate-fade-in">
                <CourseCard {...course} />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-16 md:py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">How Smart Learn Works</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Our platform makes learning accessible, engaging, and effective with a simple three-step process.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-6 animate-fade-in">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary-100 text-primary-600 mb-4">
                <BookOpen className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-semibold mb-3">1. Choose Your Course</h3>
              <p className="text-gray-600">
                Browse our extensive catalog of courses and select the ones that align with your goals and interests.
              </p>
            </div>
            
            <div className="text-center p-6 animate-fade-in" style={{ animationDelay: '0.2s' }}>
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-secondary-100 text-secondary-600 mb-4">
                <PlayCircle className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-semibold mb-3">2. Learn at Your Pace</h3>
              <p className="text-gray-600">
                Access high-quality content, engage with instructors, and learn at your own pace with our flexible platform.
              </p>
            </div>
            
            <div className="text-center p-6 animate-fade-in" style={{ animationDelay: '0.4s' }}>
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-accent-100 text-accent-600 mb-4">
                <Award className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-semibold mb-3">3. Earn Certificates</h3>
              <p className="text-gray-600">
                Complete courses, pass assessments, and earn recognized certificates to showcase your achievements.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-16 md:py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">What Our Students Say</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Hear from some of our satisfied students about their learning experiences with Smart Learn.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 animate-fade-in">
              <div className="flex items-center mb-4">
                <div className="h-12 w-12 rounded-full overflow-hidden mr-4">
                  <img 
                    src="https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                    alt="Student" 
                    className="h-full w-full object-cover"
                  />
                </div>
                <div>
                  <h4 className="font-semibold">Michael Johnson</h4>
                  <p className="text-sm text-gray-600">Web Development Student</p>
                </div>
              </div>
              <p className="text-gray-700 italic">
                "The Web Development Bootcamp transformed my career. The curriculum was comprehensive and the instructor support was exceptional. I landed a job within a month of completing the course!"
              </p>
              <div className="flex text-yellow-500 mt-4">
                <Star className="h-4 w-4 fill-current" />
                <Star className="h-4 w-4 fill-current" />
                <Star className="h-4 w-4 fill-current" />
                <Star className="h-4 w-4 fill-current" />
                <Star className="h-4 w-4 fill-current" />
              </div>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 animate-fade-in" style={{ animationDelay: '0.2s' }}>
              <div className="flex items-center mb-4">
                <div className="h-12 w-12 rounded-full overflow-hidden mr-4">
                  <img 
                    src="https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                    alt="Student" 
                    className="h-full w-full object-cover"
                  />
                </div>
                <div>
                  <h4 className="font-semibold">Sarah Williams</h4>
                  <p className="text-sm text-gray-600">Data Science Student</p>
                </div>
              </div>
              <p className="text-gray-700 italic">
                "The Data Science course provided me with practical skills that I use every day in my job. The project-based approach and real-world datasets made learning both fun and relevant."
              </p>
              <div className="flex text-yellow-500 mt-4">
                <Star className="h-4 w-4 fill-current" />
                <Star className="h-4 w-4 fill-current" />
                <Star className="h-4 w-4 fill-current" />
                <Star className="h-4 w-4 fill-current" />
                <Star className="h-4 w-4 fill-current" />
              </div>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 animate-fade-in" style={{ animationDelay: '0.4s' }}>
              <div className="flex items-center mb-4">
                <div className="h-12 w-12 rounded-full overflow-hidden mr-4">
                  <img 
                    src="https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                    alt="Student" 
                    className="h-full w-full object-cover"
                  />
                </div>
                <div>
                  <h4 className="font-semibold">David Chen</h4>
                  <p className="text-sm text-gray-600">Computer Science Student</p>
                </div>
              </div>
              <p className="text-gray-700 italic">
                "The quality of instruction at Smart Learn is outstanding. The professors are experts in their fields and the interactive learning platform makes complex topics much easier to understand."
              </p>
              <div className="flex text-yellow-500 mt-4">
                <Star className="h-4 w-4 fill-current" />
                <Star className="h-4 w-4 fill-current" />
                <Star className="h-4 w-4 fill-current" />
                <Star className="h-4 w-4 fill-current" />
                <Star className="h-4 w-4 fill-current" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-20 bg-gradient-to-r from-primary-600 to-primary-800 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Start Your Learning Journey?</h2>
          <p className="text-lg text-primary-100 mb-8 max-w-2xl mx-auto">
            Join thousands of students already learning on Smart Learn and transform your future today.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link to="/courses" className="btn btn-accent btn-lg">
              Browse Courses
            </Link>
            <Link to="/register" className="btn btn-lg bg-white text-primary-700 hover:bg-gray-100">
              Sign Up for Free
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 md:py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">Why Choose Smart Learn</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Our platform offers a unique learning experience with features designed to help you succeed.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="p-6 animate-fade-in">
              <CheckCircle className="h-10 w-10 text-primary-600 mb-4" />
              <h3 className="text-xl font-semibold mb-3">Expert Instructors</h3>
              <p className="text-gray-600">
                Learn from industry professionals and academic experts with years of experience.
              </p>
            </div>
            
            <div className="p-6 animate-fade-in" style={{ animationDelay: '0.2s' }}>
              <CheckCircle className="h-10 w-10 text-primary-600 mb-4" />
              <h3 className="text-xl font-semibold mb-3">Flexible Learning</h3>
              <p className="text-gray-600">
                Study at your own pace with 24/7 access to course materials from anywhere.
              </p>
            </div>
            
            <div className="p-6 animate-fade-in" style={{ animationDelay: '0.4s' }}>
              <CheckCircle className="h-10 w-10 text-primary-600 mb-4" />
              <h3 className="text-xl font-semibold mb-3">Interactive Content</h3>
              <p className="text-gray-600">
                Engage with videos, quizzes, projects, and discussions for effective learning.
              </p>
            </div>
            
            <div className="p-6 animate-fade-in" style={{ animationDelay: '0.6s' }}>
              <CheckCircle className="h-10 w-10 text-primary-600 mb-4" />
              <h3 className="text-xl font-semibold mb-3">Recognized Certificates</h3>
              <p className="text-gray-600">
                Earn certificates that are recognized by employers and educational institutions.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}